﻿ZJudge 用户手册 - v1.2.0

- v1.1.0 更新内容

    	1. 修复了若干 BUG
	2. 现在新建数据点不需要指定编号了，系统会自动分配
	3. 新增了批量新建数据点功能

- v1.1.1 更新内容

	1. RankList 命令现在能显示总得分了 

- v1.1.2 更新内容

	1. 修复了选手总分计算的错误
	2. 删除了多余的调试信息

- v1.2.0 更新内容

	1. 修复了评测过慢的问题
	2. 支持 SpecialJudge
	3. 修改了若干 BUG

0. 前言

    Zjudge 是一款由 zombie462 开发的、基于控制台的 c++ 源文件评测程序。该程序使用 c++ 编写

1. 编译设置

    ZJudge 目前只支持 c++ 源文件的评测

    1.1. 修改编译指令

	CompileOption +o2		开启 -O2 开关
	CompileOption -o2		关闭 -O2 开关
	CompileOption +cpp11		开启 -std=c++11 开关
	CompileOption -cpp11		关闭 -std=c++11 开关
 	CompileOption +stack %d		开启 -Wl,--stack=%d 开关
	CompileOption -stack		关闭 -Wl,--stack 开关

	默认的配置是 -O2 -Wl,--stack=128000000 -std=c++11

    1.2. 查看编译指令

	PrintCompile			打印当前的编译指令

2. 题目设置

    2.1. 增加/删除题目

	AddProblem %s			新建题目 %s
	DelProblem %s			删除题目 %s

    2.2. 题目指针

	一般情况下和“题目”有关的命令都默认在指针指向的题目进行

	CdProblem %s			修改题目指针至题目 %s

	在新建题目时会将指针指向新建的题目

	Status				查询当前的题目/选手指针

    2.3. 查看题目信息

	PrintProblem			打印题目列表
	ProblemDetail			打印当前题目详细信息

    2.4. 修改题目配置

	CdInputFile			修改当前题目输入文件
	CdOutputFile			修改当前题目输出文件

	选手需要从输入文件读入信息，并向输出文件输出

	新建题目时默认输入/输出文件名为 文件名.in/.out

	源文件名默认为 文件名.cpp，目前无法修改

	CdProblemPath			修改当前题目的路径

	数据点会在该路径下寻找。修改路径时会清空当前题目的数据点信息

    2.5. 数据点配置

	
	AddTestData %d %s1 %s2		（v1.0.0）
	AddTestData %s1 %s2		（v1.1.0 以后）
					输入文件在 %s1 处，输出文件在 %s2 处
					输入和输出文件应放在题目的路径下
					在版本 v1.0.0 你需要额外指定数据点编号 %d
					在版本 v1.1.0 以后则不用
	AddTestDatas %s1 %s2 %d1 %d2	（v1.1.0 以后）
					批量添加数据点。%s1 %s2 分别表示输入/输出格式，%d1 %d2 分别表示数据点区间
					系统将用 %d1~%d2 中的值以此匹配 %s1 %s2 中的字符 '#' 生成对应的输入/输出文件
					比如 AddTestDatas data#.in data#.out 1 10 表示依次添加测试点 data1.in/.out~data10.in/.out

	测试点默认的分数为 0 分，时间限制为 1.0 秒

	DelTestData %d			删除当前题目中编号为 %d 的数据点
	RefreshScore			为当前题目的所有测试点平均分配分数
	SetScore %d1 %d2		修改当前题目编号为 %d1 的数据点的分数为 %d2
	SetDefaultTime %f		为当前题目的所有测试点设置时间限制为 %f（秒）
	SetTime %d %f			修改当前题目编号为 %d 的数据点的时间限制为 %f

	由于技术限制，无法设置空间限制

    2.6. 评测方式（v1.2.0 以后）

	SetCompareMode			修改比较方式
	
	- SetCompareMode Traditional		修改为传统比较方式（默认）
	- SetCompareMode SpecialJudge %s	修改为 SpecialJudge 比较方式。SPJ 路径为 %s

	SpecialJudge 使用方式：

	Zjudge 的 SPJ 仅支持 .exe 格式的 SpecialJudge。你的 SPJ 应当从题目的输入路径读入标准输入信息，从输出路径读入选手输出信息，从指定文件 ans.ans 读取标准输出信息。
	
	你的 SPJ 不应当从标准输入输出读入或输出任何信息。

3. 选手设置

    3.1. 增加/删除选手
	
	AddStudent %s			增加选手 %s
	DelStudent %s			删除选手 %s

    3.2. 选手指针

	一般情况下和“选手”有关的命令都默认在指针指向的选手进行

	CdStudent %s			修改选手指针至选手 %s

	在新建选手时会将指针指向新建的选手

	Status				查询当前的题目/选手指针

    3.3. 修改选手配置

	CdStudentPath			修改当前选手的路径

	选手的源文件会在该路径下寻找。不需要建立子文件夹

    3.4. 查看选手信息

 	StudentDetail			打印当前选手的详细信息
	StudentStatus %s		打印当前选手在题目 %s 的详细信息

    3.5. 测评

	JudgeProblem %s			评测当前选手的 %s 题目
	JudgeAll			评测当前选手的所有题目

	目前测评器只能返回 答案错误、答案正确、时间超限 三种类型的信息

    3.6. 成绩表

	RankList			打印所有选手的成绩，并排名

	分数相同选手的排名相同

4. 其它

	Version				打印程序的版本
	Clrscr				清屏
	Exit				退出