#include "console.h" 
using namespace std;
void setColor(int colorID){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),colorID);
}
void clrscr(){
	setColor(0x0f);system("cls");
}
void tellraw(RawText s){
	int len=s.text.size();
	int foreColor=15,backColor=0;
	setColor(backColor<<4|foreColor);
	int idxStr=0,idxNum=0;
	for (int i=0;i<len;++i){
		switch (s.text[i]){
			case '&':
				foreColor=toHex(s.text[i+1]);
				setColor(backColor<<4|foreColor);
				i++;break;
			case '#':
				backColor=toHex(s.text[i+1]);
				setColor(backColor<<4|foreColor);
				i++;break;	
			case '|':
				switch (s.text[i+1]){
					case 'c':clrscr();break;
					case 'r':_getch();break;
					default:putchar(s.text[i+1]);
				}
				i++;break;
			case '%':
				switch (s.text[i+1]){
					case 's':
						cout<<s.strList[idxStr];
						idxStr++;
						break;
					case 'd':
						cout<<s.numList[idxNum];
						idxNum++;
						break;
				}
				i++;break;
			default:
				putchar(s.text[i]);
		}
	}
}
int chosenbox(RawText s){
    int len=s.text.size(),i=0;
    pair <int,int> tmp=getpos();
    string t="";
    vector <int> bufNum;bufNum.clear();
    vector <string> bufStr;bufStr.clear();
    int idxStr=0,idxNum=0;
    while (s.text[i]!='@' && i<len){
    	if (s.text[i]=='%' && (i==0 || s.text[i-1]!='|')){
    		if (s.text[i+1]=='s'){
    			bufStr.push_back(s.strList[idxStr]);idxStr++;
			}else{
				bufNum.push_back(s.numList[idxNum]);idxNum++;
			}
		}
		t=t+s.text[i];i++;
	}
    tellraw({t,bufNum,bufStr});
    int j=i;
    t="";bufNum.clear();bufStr.clear();
    int item=0;
    for (int i=j+1;i<len;++i){
        if (s.text[i]=='^'){ 
            j=i;
            break;
        }else if (s.text[i]=='@'){
            item++;
            gotoxy(tmp.first+item,tmp.second);
            tellraw({"    &b"+toStr(item)+". &f"+t,bufNum,bufStr});
            t="";bufNum.clear();bufStr.clear();
        }else{
	    	if (s.text[i]=='%' && (i==0 || s.text[i-1]!='|')){
	    		if (s.text[i+1]=='s'){
	    			bufStr.push_back(s.strList[idxStr]);idxStr++;
				}else{
					bufNum.push_back(s.numList[idxNum]);idxNum++;
				}
			}
			t=t+s.text[i];
        }
    }
    t="";bufNum.clear();bufStr.clear();
    for (int i=j+1;i<len;++i){
    	if (s.text[i]=='%' && (i==0 || s.text[i-1]!='|')){
    		if (s.text[i+1]=='s'){
    			bufStr.push_back(s.strList[idxStr]);idxStr++;
			}else{
				bufNum.push_back(s.numList[idxNum]);idxNum++;
			}
		}
		t=t+s.text[i];
    }
    gotoxy(tmp.first+item+1,tmp.second);
    tellraw({t,bufNum,bufStr});
    gotoxy(tmp.first+1,tmp.second);
    tellraw({"&f-->"});
    char c=_getch();
    int chosen=1;
    while (c!=' '){
        if (c=='W' || c=='w'){
            if (chosen>1){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen--;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw({"&f-->"});
            }
        }else if (c=='S' || c=='s'){
            if (chosen<item){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen++;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw({"&f-->"});
            }           
        }else if (c>='1' && c<='9' && c-48<=item){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=c-48;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw({"&f-->"});           
        }else if (c=='A' || c=='a'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=1;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw({"&f-->"});           
        }else if (c=='D' || c=='d'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=item;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw({"&f-->"});           
        }
        c=_getch();
    }
    gotoxy(tmp.first+item+2,tmp.second);
    return chosen;	
}
string inputbox(RawText s){
	showCursor();
	tellraw(s);putchar('\n');
	setColor(0x07);
	string res="";
	while (res=="") cin>>res;
	hideCursor();
	return res;
}
void initWindow(string title,int height,int width){
	system(("title "+title).c_str());
	system(("mode con cols="+toStr(width)+" lines="+toStr(height)).c_str());
}
string toStr(int x){
	string ans="";;
	if (x==0) return "0";
	bool flag=false;
	if (x<0) flag=true,x=-x;
	while (x){
		ans=(char)(x%10+48)+ans;
		x/=10;
	}
	if (flag) return "-"+ans;
	else return ans;
}
int toHex(char x){
	if (x>='0' && x<='9') return x-48;
	else return x-'a'+10;
}
int toInt(string s){
	int i=0,x=0,f=1;
	if (s[0]=='-') f=-1,i=1;
	while (i<s.size()){
		x=x*10+s[i]-48;
		i++;
	}
	return x*f;
}
void gotoxy(int x,int y){
    COORD pos;
    pos.X=y-1;
    pos.Y=x-1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
pair <int,int> getpos(){
    HANDLE hStdout;
    CONSOLE_SCREEN_BUFFER_INFO pBuffer; 
    hStdout=GetStdHandle(STD_OUTPUT_HANDLE); 
    GetConsoleScreenBufferInfo(hStdout,&pBuffer); 
    return make_pair(pBuffer.dwCursorPosition.Y+1,pBuffer.dwCursorPosition.X+1);
}
void hideCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=0;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void showCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=1;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
