#include <bits/stdc++.h>
#include <windows.h>
#include <conio.h>
using namespace std;
struct RawText{
	string text;
	vector <int> numList;
	vector <string> strList;
};
void clrscr(); 
void setColor(int colorID);
void tellraw(RawText s);
int chosenbox(RawText s);
string inputbox(RawText s);
string toStr(int x);
int toInt(string s);
int toHex(char x);
void initWindow(string title,int height,int width);
void gotoxy(int x,int y);
pair <int,int> getpos();
void hideCursor();
void showCursor();
