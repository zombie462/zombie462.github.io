#include <bits/stdc++.h>
#include "console.h"
using namespace std; 
char s[10086],t[10086],ans[10086];
vector <pair <string,string>> wordList;
enum Status{
	AC,WA,ERR
};
void addwords(){
	clrscr();
	tellraw({"&bAdd words:\n"});
	showCursor();
	while (true){
		tellraw({"&eThe spelling of the word (An empty line to finish):\n"});
		setColor(0x07);gets(s);
		if (strlen(s)==0) return;
		tellraw({"&eThe meaning of the word:\n"});
		setColor(0x07);gets(t);		
		bool flag=true;
		for (auto &x:wordList){
			if ((string)s==x.first){
				flag=false;
				x.second=t;
				break;
			}
		}
		if (flag) wordList.push_back(make_pair((string)s,(string)t));
	}
}
void delwords(){
	clrscr();
	tellraw({"&bDelete words:\n"});
	showCursor();
	while (true){
		tellraw({"&eThe word you wanna to delete (An empty line to finish):\n"});
		setColor(0x07);gets(s);
		if (strlen(s)==0) return;
		bool flag=false;
		for (vector < pair <string,string> >::iterator itList=wordList.begin();itList!=wordList.end();){
			if ((*itList).first==s){
				flag=true;wordList.erase(itList);
			}else itList++;
		}
		if (!flag){
			tellraw({"&cFailed.\n|r"});
		}
	}
}
string savename;
string rar(string s){
	string res="";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]==' ') res=res+'^';
		else res=res+s[i];
	}
	return res;
}
string derar(string s){
	string res="";
	for (int i=0;i<(int)s.size();++i){
		if (s[i]=='^') res=res+' ';
		else res=res+s[i];
	}
	return res;	
}
void loadwords(){
	tellraw({"&bThe name of the file that you are going to load:\n"});
	showCursor();
	setColor(0x07);gets(s);
	savename=s;
	ifstream infile;infile.open("save/"+savename+".sav");
	int n;string s,t;
	infile>>n;
	for (int i=1;i<=n;++i){
		infile>>s>>t;
		wordList.push_back(make_pair(derar(s),derar(t)));
	}
	infile.close();
}
void savewords(){
	if (savename=="untitled"){
		tellraw({"&bThe name of the file that you will save this word list:\n"});
		showCursor();
		setColor(0x07);gets(s);	
		savename=s;	
	}
	ofstream outfile;outfile.open("save/"+savename+".sav");
	outfile<<wordList.size()<<endl;
	for (auto &x:wordList){
		outfile<<rar(x.first)<<endl;
		outfile<<rar(x.second)<<endl;
	}
	outfile.close();
	wordList.clear();
}
inline Status check(auto exp,auto src){
	transform(exp.begin(),exp.end(),exp.begin(),::tolower);
	transform(src.begin(),src.end(),src.begin(),::tolower);
	auto unimportant = [=](auto &s) { 
		return s=="sb" || s=="sth" || s=="..." || s=="." || s==".." || s==" " || s=="" || s=="......" || s=="one's" || s=="that";
	};
	stringstream ans(exp),ouf(src);
	string a,b;
	bool test=false;
	while (ans>>a){
		if (a.find("(")!=string::npos) test=true;
		if (!unimportant(a) && !test){
			do{
				if (!(ouf>>b)) break;
			}while (unimportant(b));
			if (a!=b) return WA;
		}
		if (a.find(")")!=string::npos) test=false;
	}
	return AC;
}
void study(){
	tellraw({"&bThe name of the file that you are going to load:\n"});
	showCursor();setColor(0x07);
	gets(s);
	ifstream infile;
	infile.open("save/"+(string)s+".sav");
	int n;infile>>n;
	string s,t;
	for (int i=1;i<=n;++i){
		infile>>s>>t;
		wordList.push_back(make_pair(derar(s), derar(t)));
	}
	infile.close();
	random_shuffle(wordList.begin(), wordList.end());
	int ac=0,wa=0;
	for (int i=0;i<(int)wordList.size();++i){
		clrscr();
		tellraw({"&fCurrent status: &a%d&f/%d First accept = &a%d\n",{i+1,(int)wordList.size(),ac},{}});
		tellraw({"&b%d.&f &e%s\n",{i+1},{wordList[i].second}});
		setColor(0x07);
		gets(ans);string fuckyou=ans;
		if (check(wordList[i].first,fuckyou)==AC){
			tellraw({"&aAccepted. std = \"%s\"\n|r",{},{wordList[i].first}});
			if (i<n) ac++;
		}else{
			tellraw({"&cWrong Answer. Correct answer is \"%s\"\n|r",{},{wordList[i].first}});
			wordList.push_back(make_pair(wordList[i].first, wordList[i].second));
			wa++;
		}
	}
	clrscr();
	tellraw({"&fWord count = &e%d&f, Wrong time = &c%d&f, First time accept = &a%d&f (&a%d&f|%)\n|r",{n,wa,ac,(int)((double)ac/(ac+wa)*100)}});
}
void create(){
	while (true){
		clrscr();hideCursor();
		int tot=0;
		tellraw({"&bWord List:"}); 
		for (auto &x:wordList){
			tot++;
			gotoxy(tot+1,1);
			tellraw({"&b%d. &f%s",{tot},{x.first}});
			gotoxy(tot+1,25);
			tellraw({"&8%s",{},{x.second}});
		}
		gotoxy(tot+3,1);
		switch (chosenbox({"&bChoose your operation:@&aAdd words@&cDelete words@&dSave and exit@&cExit without save@^"})){
			case 1:
				addwords();
				break;
			case 2:
				delwords();
				break;
			case 3:
				savewords();
				return;
			case 4:
				wordList.clear();
				return;
		}
	}
}
int main(){
	srand((unsigned)time(NULL));
	while (true){
		clrscr();hideCursor();savename="untitled";
		switch (chosenbox({"&bWelcome to English training platform!@&eLoad word list@&aCreate word list@&dStudy English@&cExit@^"})){
			case 1:
				loadwords();
				create();
				break;
			case 2:
				create();
				break;
			case 3:
				study();
				break;
			case 4:
				return 0;
		}
	}
}
