#include "console.h"
using namespace std;

void showCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=1;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void hideCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=0;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void setColor(int colorID){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),colorID);
}
void clrscr(){
    setColor(0x0f);system("cls");
}
int toHex(char c){
    if (c>='0' && c<='9') return c-'0';
    else return c-'a'+10;
}
void gotoxy(int x,int y){
    COORD pos;
    pos.X=y-1;
    pos.Y=x-1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
pair <int,int> getxy(){
    HANDLE hStdout;
    CONSOLE_SCREEN_BUFFER_INFO pBuffer; 
    hStdout=GetStdHandle(STD_OUTPUT_HANDLE); 
    GetConsoleScreenBufferInfo(hStdout,&pBuffer); 
    return make_pair(pBuffer.dwCursorPosition.Y+1,pBuffer.dwCursorPosition.X+1);
}
void setWindowSize(string name,int width,int height){
    system(("title "+name).c_str());
    char cmd[30];
    sprintf(cmd,"mode con cols=%d lines=%d",width,height);
    system(cmd);
}

Object::Object(){
	id=OBJECT;
}
void Object::show(){
	assert(!(faObject==nullptr));
	visible=1;if (faObject->visible) print();
}
void Object::hide(){
	assert(!(faObject==nullptr));
	if (STRICT_MODE) assert(!(faObject->visible));
	visible=0;faObject->print();
}
void Object::remove(){
	hide();enable=0;
}

RawText::RawText(string _text,vector <int> _numBuf,vector <string> _strBuf,vector <double> _dblBuf){
	text=_text;numBuf=_numBuf;strBuf=_strBuf;dblBuf=_dblBuf;
}
void RawText::print(int backColor){
	pair <int,int> orgPos=getxy();
	setColor((backColor<<4)|7);
	int len=text.size();
	int nowbgc=backColor,nowftc=7;
	int stridx=0,numidx=0,dblidx=0;
	for (int i=0;i<len;++i){
		if (text[i]=='/'){
			if (text[i+1]=='n'){
				gotoxy(orgPos.first+1,orgPos.second);
				orgPos.first++;
			}else putchar(text[i+1]);
			i++;
		}else if (text[i]=='&'){
			nowftc=toHex(text[i+1]);
			setColor((nowbgc<<4)|nowftc);
			i++;
		}else if (text[i]=='#'){
			nowbgc=toHex(text[i+1]);
			setColor((nowbgc<<4)|nowftc);
			i++;
		}else if (text[i]=='%'){
			if (text[i+1]=='s') cout<<strBuf[stridx++];
			else if (text[i+1]=='d') printf("%d",numBuf[numidx++]);
			else if (text[i+1]=='f') printf("%.2lf",dblBuf[dblidx++]);
			i++;
		}else putchar(text[i]);
	}
	setColor(0x07);
}
RawText::~RawText(){
	numBuf.clear();strBuf.clear();dblBuf.clear();
}
RawText toRaw(string s){
	return RawText(s);
}

void tellraw(RawText s){
	s.print();
}
void tellraw(string s){
	tellraw(RawText(s));
}

Form::Form(int _xpos,int _ypos,int _height,int _width,Form* _faObject,int _bgColor){
	xpos=_xpos;ypos=_ypos;width=_width;height=_height;bgColor=_bgColor;
	sonObjects.clear();faObject=_faObject;visible=1;id=FORM;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();
}
void Form::print(){
	string bgBuf=string(width,' ');
	setColor(bgColor<<4);
	for (int i=xpos;i<=xpos+height-1;++i){
		gotoxy(i,ypos);
		cout<<bgBuf<<endl;
	}
	for (auto &x:sonObjects){
		if (x->visible) x->print();
	}
}
Form::~Form(){
	sonObjects.clear();;
} 

void getpos(POINT &pt){
    HWND hwnd=GetForegroundWindow();
    GetCursorPos(&pt);
    ScreenToClient(hwnd,&pt);
    pt.y=pt.y/16+1;
    pt.x=pt.x/8+1;
    swap(pt.x,pt.y);
}

Button::Button(RawText _text,int _xpos,int _ypos,Form* _faObject,int _bgColor,int _bgPressColor){
	text=_text;xpos=_xpos;ypos=_ypos;bgColor=_bgColor;bgPressColor=_bgPressColor;
	faObject=_faObject;isPress=0;visible=1;width=0;enable=1;id=BUTTON;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();
}
void Button::print(){
	int bg;
	if (isPress) bg=bgPressColor;
	else bg=bgColor;
	if (!enable) bg=8;
	gotoxy(xpos,ypos);
	pair <int,int> orgPos=getxy();
	text.print(bg);
	pair <int,int> nowPos=getxy();
	width=nowPos.second-orgPos.second;
}
#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
int Button::preserve(){
	if (STRICT_MODE) assert(visible);
	if (visible) print();
	if (!enable) return 0;
	POINT pt;getpos(pt);
	if (pt.x==xpos && pt.y>=ypos && pt.y<=ypos+width-1){
		isPress=1;
		if (press(VK_LBUTTON)){
			Sleep(SLEEP_TIME);return 2;
		}else return 1;
	}
	isPress=0;
	return 0;
}

Label::Label(RawText _text,int _xpos,int _ypos,Form* _faObject){
	text=_text;xpos=_xpos;ypos=_ypos;
	faObject=_faObject;visible=1;id=LABEL;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();
}
void Label::print(){
	assert(!(faObject==nullptr));
	gotoxy(xpos,ypos);text.print(faObject->bgColor);
}

Option::Option(RawText _text,int _xpos,int _ypos,Form* _faObject,int _tickColor,char _tickChar,string _blockChar){
	text=_text;xpos=_xpos;ypos=_ypos;tickColor=_tickColor;tickChar=_tickChar;blockChar=_blockChar;
	faObject=_faObject;visible=1;chosen=0;width=0;isPress=0;id=OPTION;enable=1;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();	
}
void Option::set(int tp){
	assert(faObject!=nullptr);
	if ((tp==-1 && chosen==0) || tp==1){
		for (auto &x:faObject->sonObjects){
			if (x->id==OPTION){
				x->chosen=0;
				if (x->visible) x->print();
			}
		}
		chosen=1;
	}else{
		chosen=0;
	}
	print();
}
int Option::preserve(){
	if (STRICT_MODE) assert(visible);
	if (visible) print();
	if (!enable) return 0;
	POINT pt;getpos(pt);
	if (pt.x==xpos && pt.y>=ypos && pt.y<=ypos+width-1){
		isPress=1;
		if (press(VK_LBUTTON)){
			set();Sleep(SLEEP_TIME);return 2;
		}else return 1;
	}
	isPress=0;
	return 0;	
}
void Option::print(){
	assert(!(faObject==nullptr));
	gotoxy(xpos,ypos);
	int bgc=faObject->bgColor;
	pair <int,int> orgPos=getxy();
	if (!enable){
		setColor((bgc<<4)|8);putchar(blockChar[0]);
		if (chosen) putchar(tickChar);
		else putchar(' ');
		setColor((bgc<<4)|8);putchar(blockChar[1]);
	}else{
		setColor((bgc<<4)|15);putchar(blockChar[0]);
		if (!isPress) setColor((bgc<<4)|tickColor);
		else setColor(tickColor<<4);
		if (chosen) putchar(tickChar);
		else putchar(' ');	
		setColor((bgc<<4)|15);putchar(blockChar[1]);
	}
	text.print(bgc);
	pair <int,int> nowPos=getxy();
	width=nowPos.second-orgPos.second;
}

CheckBox::CheckBox(RawText _text,int _xpos,int _ypos,Form* _faObject,int _tickColor,char _tickChar,string _blockChar){
	text=_text;xpos=_xpos;ypos=_ypos;tickColor=_tickColor;tickChar=_tickChar;blockChar=_blockChar;
	faObject=_faObject;visible=1;chosen=0;width=0;isPress=0;id=CHECKBOX;enable=1;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();	
}
void CheckBox::set(int tp){
	assert(!(faObject==nullptr));
	if ((tp==-1 && chosen==0) || tp==1) chosen=1;
	else chosen=0;
	print();
}

ProgressBar::ProgressBar(RawText _text,int _xpos,int _ypos,int _width,Form* _faObject,int* _value,int _maxVal,int _barColor,int _style){
	text=_text;xpos=_xpos;ypos=_ypos;width=_width;barColor=_barColor;style=_style;
	value=_value;faObject=_faObject;visible=1;id=PROGRESS_BAR;maxVal=_maxVal;numLen=0;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();	
}
void ProgressBar::print(){
	assert(!(faObject==nullptr));
	int bgc=faObject->bgColor;
	gotoxy(xpos,ypos);text.print(bgc);
	string bars=string(width,' ');
	string barCol=string((int)(1.0*(*value)/maxVal*width),' ');
	if (style&1) setColor((bgc<<4)|15),putchar('[');
	pair <int,int> nowPos=getxy();
	setColor(bgc<<4);cout<<bars;
	if (style&1) setColor((bgc<<4)|15),putchar(']');
	if ((style>>1)&1){
		pair <int,int> pos1=getxy();
		string numCls=string(numLen,' ');
		setColor(bgc<<4);cout<<numCls;
		gotoxy(pos1.first,pos1.second);
		setColor((bgc<<4)|barColor);
		putchar(' ');
		cout<<(*value);
		setColor((bgc<<4)|15);
		cout<<"/"<<maxVal;
		pair <int,int> pos2=getxy(); 
		numLen=pos2.second-pos1.second;
	}
	gotoxy(nowPos.first,nowPos.second);
	setColor(barColor<<4);cout<<barCol;
}

void LabelVal::basicInit(RawText _text,int _xpos,int _ypos,Form* _faObject,int _valCol,int _maxVal){
	text=_text;xpos=_xpos;ypos=_ypos;maxVal=_maxVal;valCol=_valCol;
	faObject=_faObject;visible=1;id=LABEL_VAL;numLen=0;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;	
}
LabelVal::LabelVal(RawText _text,int _xpos,int _ypos,Form* _faObject,int* _value,int _valCol,int _maxVal){
	basicInit(_text,_xpos,_ypos,_faObject,_valCol,_maxVal);
	value=(void**)_value;dataType=_INT;print();
}
LabelVal::LabelVal(RawText _text,int _xpos,int _ypos,Form* _faObject,string* _value,int _valCol,int _maxVal){
	basicInit(_text,_xpos,_ypos,_faObject,_valCol,_maxVal);
	value=(void**)_value;dataType=_STRING;print();
}
LabelVal::LabelVal(RawText _text,int _xpos,int _ypos,Form* _faObject,double* _value,int _valCol,int _maxVal){
	basicInit(_text,_xpos,_ypos,_faObject,_valCol,_maxVal);
	value=(void**)_value;dataType=_DOUBLE;print();
}
void LabelVal::print(){
	assert(!(faObject==nullptr));
	int bgc=faObject->bgColor;
	gotoxy(xpos,ypos);text.print(bgc);
	pair <int,int> pos1=getxy();
	string numCls=string(numLen,' ');
	setColor(bgc<<4);cout<<numCls;
	gotoxy(pos1.first,pos1.second);
	setColor((bgc<<4)|valCol);
	if (dataType==_INT) cout<<*(int*)(value);
	else if (dataType==_DOUBLE) printf("%.2lf",*(double*)(value));
	else if (dataType==_STRING) cout<<*(string*)(value);
	if (!(maxVal==-1)){
		setColor((bgc<<4)|15);
		cout<<"/"<<maxVal;
	}
	pair <int,int> pos2=getxy(); 
	numLen=pos2.second-pos1.second;
}


List::List(RawText _text,int _xpos,int _ypos,int _width,Form* _faObject,vector <RawText>* _items,int _perPage,int _bgPressColor,string _pageFormat){
	text=_text;xpos=_xpos;ypos=_ypos;width=_width;visible=1;enable=1;nowPage=1;pageFormat=_pageFormat;
	faObject=_faObject;items=_items;perPage=_perPage;bgPressColor=_bgPressColor;id=LIST;
	if (faObject!=nullptr) faObject->sonObjects.push_back(this),xpos+=faObject->xpos-1,ypos+=faObject->ypos-1;
	if (faObject!=nullptr && faObject->visible) this->print();		
}
void List::print(){
	gotoxy(xpos,ypos);tellraw(text);
	int itemCnt=items->size(),pageMax=(itemCnt-1)/perPage+1; 
	if (nowPage<1) nowPage=1;
	if (nowPage>pageMax) nowPage=pageMax;
	assert(!(faObject==nullptr));
	int bgc=faObject->bgColor;
	RawText pageInfo(pageFormat,{nowPage,pageMax});pageInfo.print(bgc);
	string bgBar=string(width,' ');
	for (int i=(nowPage-1)*perPage,j=1;i<=min(itemCnt-1,nowPage*perPage-1);++i,++j){
		gotoxy(xpos+j,ypos);
		if (isChosen==i) setColor(bgPressColor<<4);
		else setColor(bgc<<4);
		if (!enable) setColor(8<<4);
		cout<<bgBar;
		gotoxy(xpos+j,ypos);
		if (isChosen==i) items->at(i).print(bgPressColor);
		else items->at(i).print(bgc);
	}
}
void List::nextPage(){
	if (STRICT_MODE) assert(visible);
	nowPage++;if (visible) hide(),show();
}
void List::prevPage(){
	if (STRICT_MODE) assert(visible);
	nowPage--;if (visible) hide(),show();
}
int List::preserve(){
	if (!enable) return -1;
	POINT pt;getpos(pt);
	int itemCnt=items->size(),pageMax=(itemCnt-1)/perPage+1;
	if (nowPage<1) nowPage=1;
	if (nowPage>pageMax) nowPage=pageMax;
	for (int i=(nowPage-1)*perPage,j=1;i<=min(itemCnt-1,nowPage*perPage-1);++i,++j){
		if (pt.x==xpos+j && pt.y>=ypos && pt.y<=ypos+width-1 && press(VK_LBUTTON)){
			isChosen=i;
			print();
			return isChosen;
		}
	}
	return -1;
}
