### 1 总览

ConsoleUI 5.0 采用的是控件模板架构，比纯基于控制台的 ConsoleUI 4.0 更高级、更人性化。

### 2 基本方法

#### 2.1 常用基本方法

| 名称          | 定义                                                         | 简介                                    |
| ------------- | ------------------------------------------------------------ | --------------------------------------- |
| showCursor    | `void showCursor()`                                          | 显示光标                                |
| hideCursor    | `void hideCursor()`                                          | 隐藏光标                                |
| clrscr        | `void clrscr()`                                              | 清空屏幕                                |
| toHex         | `int toHex(char c)`                                          | 十六进制字符（小写）转十进制            |
| setColor      | `void setColor(int colorID)`                                 | 修改输出字符颜色为 colorID（见附录 1）  |
| setWindowSize | `void setWindowSize(string name,int width,int height)`       | 修改控制台窗体标题/宽/高                |
| getxy         | `pair <int,int> getxy()`                                     | 获得当前光标所在的行/列                 |
| getPos        | `void getpos(POINT &pt)`                                     | 获得当前鼠标所在的行/列（保存在 pt 中） |
| press         | `#define press(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)` | 检测是否有键按下（见附录 2）            |

#### *附录1 - ColorID 对应表

| ColorID | 颜色                | 示例                  |
| ------- | ------------------- | -------------------------- |
| 0       | 黑色/BLACK          | **<font color=black>0</font>** |
| 1       | 深蓝色/DARK BLUE    | **<font color=#00007f>1</font>** |
| 2       | 深绿色/DARK GREEN   | **<font color=#007f00>2</font>** |
| 3       | 深青色/DARK CYAN    | **<font color=#007f7f>3</font>** |
| 4       | 深红色/DARK RED     | **<font color=#7f0000>4</font>** |
| 5       | 深紫色/DARK MAGENTA | **<font color=#7f007f>5</font>** |
| 6       | 深黄色/DARK YELLOW  | **<font color=#7f7f00>6</font>** |
| 7       | 浅灰色/GRAY         | **<font color=lightgray>7</font>** |
| 8       | 深灰色/DARK GRAY    | **<font color=#777777>8</font>** |
| 9       | 蓝色/BLUE           | **<font color=blue>9</font>** |
| 10/a    | 绿色/GREEN          | **<font color=green>a</font>** |
| 11/b    | 青色/CYAN           | **<font color=cyan>b</font>** |
| 12/c    | 红色/RED            | **<font color=red>c</font>** |
| 13/d    | 紫色/MAGENTA        | **<font color=magenta>d</font>** |
| 14/e    | 黄色/YELLOW         | **<font color=yellow>e</font>** |
| 15/f    | 白色/WHITE          | **<font color=white>f</font>** |

*控制台的默认颜色是浅灰色。

*setColor 中一般用 colorID 十六进制的高位表示背景颜色，低位表示字符颜色。如 colorID=0xcf 表示红色背景/白色字符。

#### *附录 2 - VK_NONAME 对应表

| VK_NONAME                   | 键位     |
| --------------------------- | -------- |
| VK_LBUTTON                  | 左键     |
| VK_RBUTTON                  | 右键     |
| VK_SHIFT/VK_CTRL/VK_ALT/... | 对应键位 |
| 'A'/'B'/'C'/...             | 对应键位 |

#### 2.2 RawText

和 ConsoleUI 4.0 一样，我们使用 RawText 类型来简便地表示带格式字符串。

**RawText 成员变量表：**

| 名称   | 类型              | 简介                       |
| ------ | ----------------- | -------------------------- |
| text   | `string`          | 表示带格式字符串           |
| numBuf | `vector <int>`    | 表示替代 `%d` 的数字列表   |
| strBuf | `vector <string>` | 表示替代 `%s` 的字符串列表 |
| dblBuf | `vector <double>` | 表示替代 `%f` 的浮点数列表 |

其中，带格式字符串，是一个一般字符串中间插入一些表示格式的字符短语（如 `&d`）等，来表达修改格式的意义。

**具体地：**

| 名称 | 简介                                               | 示例                                |
| ---- | -------------------------------------------------- | ----------------------------------- |
| &X   | 将之后字符输出的颜色变为 X                         | &c 字符颜色变为红色                 |
| #X   | 将之后字符输出的背景颜色变为 X                     | #c 字符背景颜色变为红色             |
| %X   | 从 numBuf/strBuf/dblBuf 中调出下一个元素输出       | %d 表示从 numBuf 调出下一个元素输出 |
| /X   | 直接输出 X 字符（用于转义）。`/n` 不适用此条规则。 | 略                                  |
| /n   | 换行。且列坐标和第一个字符相等。                   | 略                                  |

**和它有关的方法有：**

构造函数：`RawText(string _text="",vector <int> numBuf={},vector <string> strBuf={},vector <double> dblBuf={})`

| 名称           | 定义                                   | 简介                                              |
| -------------- | -------------------------------------- | ------------------------------------------------- |
| RawText::print | `void RawText::print(int backColor=0)` | 输出 RawText 中的内容，且默认背景颜色为 backColor |
| toRaw          | `RawText toRaw(string s)`              | string 转 RawText                                 |
| tellraw        | `void tellraw(RawText s)`              | 等价于 s.print()                                  |
| tellraw        | `void tellraw(string s)`               | 等价于 toRaw(s).print()                           |

### 3 控件

主要详解 Object 类的内容。

#### 3.1 通用

所有继承于 Object 的类都有这些通用成员。

**通用成员变量：**

| 名称      | 类型          | 简介                     |
| --------- | ------------- | ------------------------ |
| visible   | `bool`        | 是否可见                 |
| chosen    | `bool`        | 保留作 option 类         |
| enable    | `bool`        | 是否可用                 |
| xpos/ypos | `int`         | 左上角行/列坐标          |
| faObject  | `Form*`       | 父对象。详见 Form 类解释 |
| id        | `OBJECT_TYPE` | 控件类型                 |

*OBJECT_TYPE

```cpp
enum OBJECT_TYPE{
	OBJECT,FORM,BUTTON,LABEL,OPTION,CHECKBOX,PROGRESS_BAR,LABEL_VAL,LIST
};
```

*注意：所有控件的 xpos/ypos 为关于它父对象的**相对坐标**。

**通用成员函数：**

构造函数：`Object()`

| 名称   | 定义                   | 简介                               |
| ------ | ---------------------- | ---------------------------------- |
| remove | `void remove()`        | 移除控件                           |
| hide   | `void hide()`          | 隐藏控件（本质上是重新打印父控件） |
| show   | `void show()`          | 显示控件                           |
| print  | `virtual void print()` | 输出控件                           |

#### 3.2 Form

Form 控件是控件的载体。任何其他控件都应该被包含在某一个 Form 里，作为它的子控件。Form 之间的嵌套关系形成一棵树。

**成员变量：**

| 名称       | 类型               | 简介               |
| ---------- | ------------------ | ------------------ |
| width      | `int`              | 控件宽度           |
| height     | `int`              | 控件高度           |
| bgColor    | `int`              | 控件背景颜色       |
| sonObjects | `vector <Object*>` | 该控件包含的子控件 |

**成员函数：**

构造函数：`Form(int _xpos=0,int _ypos=0,int _width=0,int _height=0,Form* _faObject=nullptr,int _bgColor=0)`

#### 3.3 Button

按钮控件。

**成员变量：**

| 名称         | 类型      | 简介                               |
| ------------ | --------- | ---------------------------------- |
| bgColor      | `int`     | 按钮背景颜色                       |
| bgPressColor | `int`     | 按钮被触碰（不一定点击）时背景颜色 |
| isPress      | `bool`    | 按钮是否被触碰                     |
| text         | `RawText` | 按钮上显示字符                     |

**成员函数：**

构造函数：`Button(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _bgColor=0,int _bgPressColor=0)`

| 名称     | 定义             | 简介                                                         |
| -------- | ---------------- | ------------------------------------------------------------ |
| preserve | `int preserve()` | 维护按钮。如果按钮被触碰，返回 1；如果按钮被点击，返回 2；否则返回 0 |

*所有的维护按钮函数只会判定一次，所以你应当使用 `while (1)` 等语句连续地判定。

#### 3.4 Label

标签控件。简称文本框。

**成员变量：**

| 名称 | 类型      | 简介             |
| ---- | --------- | ---------------- |
| text | `RawText` | 标签上显示的字符 |

**成员函数：**

构造函数：`Label(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr)`

#### 3.5 Option

单选框控件。同一个 Form 的直系子单选框只能有一个被选中。

**成员变量：**

| 名称      | 类型      | 简介                                                  |
| --------- | --------- | ----------------------------------------------------- |
| tickChar  | `char`    | 选择时显示的“钩”的字符                                |
| tickColor | `int`     | 选择时显示的“钩”的颜色                                |
| text      | `RawText` | 单选框显示的字符                                      |
| blockChar | `string`  | 显示的框的字符类型。第一和第二个字符分别表示左/右边框 |
| isPress   | `bool`    | 单选框是否被触碰                                      |
| chosen    | `int`     | 单选框是否被选择                                      |

**成员函数：**

构造函数：`Option(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _tickColor=10,char _tickChar='X',string _blockChar="()")`

| 名称     | 定义                          | 简介                                                 |
| -------- | ----------------------------- | ---------------------------------------------------- |
| set      | `virtual void set(int tp=-1)` | 将选择框的状态改成 tp。如果未定义 tp，则默认翻转状态 |
| preserve | `int preserve()`              | 同按钮的 preserve（点击时还会自动更改选择框状态）    |

#### 3.5.1 CheckBox

多选框控件。同一个 Form 的直系子多选框可以有多个被选中。

构造函数：`CheckBox(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int _tickColor=10,char _tickChar='O',string _blockChar="[]")`

#### 3.6 ProgressBar

进度条控件。可以选择绑定一个变量指针来实时反馈其与总量的关系。

**成员变量：**

| 名称     | 类型      | 简介                 |
| -------- | --------- | -------------------- |
| width    | `int`     | 进度条长度           |
| barColor | `int`     | 进度条颜色           |
| style    | `int`     | 进度条风格           |
| maxVal   | `int`     | 进度条上限           |
| value    | `int*`    | 进度条绑定的变量指针 |
| text     | `RawText` | 进度条标题           |

*进度条的风格是一个两位二进制整数。高位表示是否显示形如 `X/Y` 的数字，低位表示是否将进度条用中括号括起来。

**成员函数：**

构造函数：`ProgressBar(RawText _text,int _xpos=0,int _ypos=0,int _width=0,Form* _faObject=nullptr,int* _value=nullptr,int _maxVal=100,int _barColor=12,int _style=0)`

*使用 print 函数实时更新进度条状态。

#### 3.7 LabelVal

带变量的标签。

**成员变量：**

| 名称     | 类型        | 简介                               |
| -------- | ----------- | ---------------------------------- |
| text     | `RawText`   | 标签显示的文字                     |
| value    | `void**`    | 标签绑定的变量                     |
| maxVal   | `int`       | 标签显示的上限值（为 -1 则不显示） |
| dataType | `DATA_TYPE` | 标签绑定的变量类型                 |
| valCol   | `int`       | 标签显示的变量颜色                 |

*DATA_TYPE

```cpp
enum DATA_TYPE{
	_INT,_DOUBLE,_STRING
};
```

**成员函数**

构造函数：

+ `LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,int* _value=nullptr,int _valCol=14,int _maxVal=-1);`
+ `LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,double* _value=nullptr,int _valCol=14,int _maxVal=-1);`
+ `LabelVal(RawText _text,int _xpos=0,int _ypos=0,Form* _faObject=nullptr,string* _value=nullptr,int _valCol=14,int _maxVal=-1);`

*使用 print 函数实时更新标签状态。

#### 3.8 List

列表控件。

**成员变量：**

| 名称         | 类型                | 简介                                                         |
| ------------ | ------------------- | ------------------------------------------------------------ |
| text         | `RawText`           | 列表的标题                                                   |
| items        | `vector <RawText>*` | 绑定的 vector 作为列表                                       |
| perPage      | `int`               | 单页显示的页数                                               |
| width        | `int`               | 列表主体的宽度                                               |
| isChosen     | `int`               | 列表被选中的项                                               |
| bgPressColor | `int`               | 项目被选中时的颜色                                           |
| nowPage      | `int`               | 列表所处的列数                                               |
| pageFormat   | `string`            | 显示页数的格式（使用 RawText 格式，允许使用两个 %d 表示当前页数和总页数） |

**成员函数：**

构造函数：`List(RawText _text,int _xpos=0,int _ypos=0,int _width=0,Form* _faObject=nullptr,vector <RawText>* _items=nullptr,int _perPage=5,int _bgPressColor=7,string _pageFormat="第 &e%d&7//%d 页")`

| 名称     | 定义               | 简介                                                        |
| -------- | ------------------ | ----------------------------------------------------------- |
| preserve | `int preserve()`   | 维护列表。如果点击了列表的某一项，返回它的编号；否则返回 -1 |
| nextPage | `void nextPage()`  | 前进至下一页（自带 print）                                  |
| prevPage | `void printPage()` | 后退至上一页（自带 print）                                  |

*你可能需要额外自行定义几个按钮来实现换页功能。

### 4. 控件示例

#### 4.1 Form 示例

这个程序能够让你大概了解 Form 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - Form",90,45); //重定义控制台窗口大小/宽度/高度
	hideCursor(); //隐藏光标
	Form mainForm(1,1,45,90,nullptr,0); //创建一个左上角位于 (1,1) 的 Form，其高度/宽度分别为 45/90。这是一个主框架，所以没有父框架。背景颜色为 0（黑色）
	Form Form1(5,10,35,70,&mainForm,1); //创建一个左上角相对于其父框架 mainForm 位于 (5,10) 的 Form。其它同理
	Form Form2(5,10,25,50,&Form1,2);
	Form Form3(3,4,21,21,&Form2,3);
	Form Form4(3,27,21,21,&Form2,4);
	_getch();
	Form3.hide(); //隐藏指令
	_getch();
	Form3.show(); //显示指令
	_getch();
	Form2.hide();
	_getch();
	Form2.show();
	_getch(); 
	showCursor();
}
```

**注意事项：**

+ 整个程序尽可能只有一个 Form 没有父框架。因为没有父框架的控件几乎不支持任何功能。
+ 子框架的大小必须严格小于父框架的大小，否则在显示上会出现问题。
+ 再次提醒：控件的坐标为其相对于父框架的坐标。
+ 在程序运行时不要缩放控制台窗口，否则会出现不可预料的错误。
+ 任何控件在被创建时，如果其父控件显示，则程序会试图显示该控件。

#### 4.2 Button 示例

这个程序能够让你大概了解 Button 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - Button",90,45);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	Button bt(toRaw("  &f关闭程序  "),10,20,&mainForm,4,12); //创建按钮，按钮的宽度会由按钮上的文字自动生成。按钮在触碰时显示红色（12），未触碰时显示深红色（4）
	while (1){ //持续地维护按钮
		if (bt.preserve()==2) break; //如果按钮被点击，则退出程序
	}
	bt.hide();
	showCursor();
}
```

**注意事项：**

+ 为了正常地进行鼠标操作，**请关闭控制台的“快速编辑模式”**。

#### 4.3 Label 示例

这个程序能够让你大概了解 Label 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - Label",90,45);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	Label lb(toRaw("&f欢迎/n这里是 &eConsoleUI5.0&f/n如果有什么问题请联系 &bCrystal302"),10,20,&mainForm); //这是一个显示多行字符的 Label
	_getch();
	showCursor();
}
```

**注意事项：**

+ 注意 RawText 中 `\n` 和 `/n` 的区别，前者是换行字符，后者是 RawText 控制字符。后者换行时还将与整句话的第一个字符列坐标对齐。

#### 4.4 Option & CheckBox 示例

这个程序能够让你大概了解 Option 或 CheckBox 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - Option&CheckBox",90,45);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	Form form1(1,1,45,90,&mainForm,0);
	Label lb(toRaw("&f请选择：/n你的性别：/n/n你掌握的语言："),10,20,&form1);
	Option opMale(toRaw("&b男"),12,20,&form1,11);
	Option opFemale(toRaw("&c女"),12,32,&form1,12);
	CheckBox chkCpp(toRaw("&bC++"),14,20,&form1,11);
	CheckBox chkJava(toRaw("&cJava"),14,32,&form1,12);
	Button bt(toRaw("  &f确定  "),16,24,&form1,2,10);
	while (1){
		opMale.preserve(); //维护四个选项框
		opFemale.preserve();
		chkCpp.preserve();
		chkJava.preserve();
		bt.enable=(opMale.chosen || opFemale.chosen) && (chkCpp.chosen || chkJava.chosen); //如果有选择按钮才启用
		if (bt.preserve()==2) break;
	}
	opMale.visible=opFemale.visible=chkCpp.visible=chkJava.visible=bt.visible=0;
	lb.text.text="&a感谢你做出的选择";form1.show();form1.print(); //控件.text.text 表示显示的 RawText 字符串
	_getch();
	showCursor();
}
```

**注意事项：**

+ 在需要同时隐藏一个 Form 内的多个控件时，不建议使用 `hide()`，而是采取修改 `visible`+手动打印父框架的方法。

#### 4.5 ProgressBar 示例

这个程序能够让你大概了解 ProgressBar 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - ProgressBar",90,45);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	int val=0;
	ProgressBar pb(toRaw("&f进度条"),10,10,20,&mainForm,&val,100,12,3); //进度条长度为 20，颜色为红色（12），风格为 3
	Label lb(toRaw("按任意键增加进度条进度..."),8,10,&mainForm);
	while (val<100){
		_getch();val++;pb.print(); //需要用 print 实时更新进度条状态
	}
	_getch();
	showCursor();
}
```

#### 4.6 LabelVal 示例

这个程序能够让你大概了解 LabelVal 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - LabelVal",90,45);
	hideCursor();
	Form mainForm(1,1,45,90,nullptr,0);
	int val=0,maxVal=10;
	LabelVal lv(toRaw("&f金币数："),10,10,&mainForm,&val,14,maxVal);
	Label lb(toRaw("按任意键获得金币..."),16,10,&mainForm);
	Button lvlUp(toRaw("  &f提升容量  "),12,10,&mainForm,2,10);
	int upgradeCost=5; 
	LabelVal lvCost(toRaw("&f升级花费："),12,24,&mainForm,&upgradeCost,10);
	while (1){
		if (kbhit()){
			_getch();val=min(val+1,maxVal);lv.print(); //需要用 print 实时更新状态
		}	
		lvlUp.enable=(val>=upgradeCost);
		if (lvlUp.preserve()==2){
			lv.maxVal+=10,maxVal+=10; //LabelVal::maxVal 不是指针，没有绑定变量
			val-=upgradeCost,upgradeCost+=10;
			lv.print();lvCost.print(); 
		}
	}
	_getch();
	showCursor();
}
```

#### 4.7 List 示例

这个程序能够让你大概了解 List 的使用方式。

```cpp
#include "console.h"
using namespace std;
signed main(){
	setWindowSize("Example - List",90,45);
	hideCursor();
	Form mainForm=Form(1,1,90,45,nullptr,0);
	vector <RawText> lt={toRaw("&e     添加    "),toRaw("&c     退出    ")};
	List list1(toRaw("Test  "),3,6,13,&mainForm,&lt,4);
	Button pre(toRaw("  &0前一页  "),9,6,&mainForm,10,2);
	Button nxt(toRaw("  &0后一页  "),10,6,&mainForm,11,3);
	Button ok(toRaw("   &0确定   "),11,6,&mainForm,14,6);
	while (1){
		while (1){
			list1.preserve();
			if (pre.preserve()==2) list1.prevPage();
			if (nxt.preserve()==2) list1.nextPage();
			if (ok.preserve()==2) break;
		}	
		if (list1.isChosen==0) lt.push_back(toRaw("&d    新项目   "));
		else if (list1.isChosen==1) break; 
		list1.print();	
	}
	pre.visible=nxt.visible=ok.visible=list1.visible=0;
	mainForm.print(); 
	_getch();
	showCursor();
}
```

