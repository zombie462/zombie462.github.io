#include <bits/stdc++.h>
#include <Winsock2.h>
#include <windows.h> 
#include <conio.h>
#pragma comment(lib,"ws2_32.lib")
using namespace std;
namespace Client{
	WORD wVersionRequested;
	WSADATA wsaData;
	SOCKET sockClient;
	SOCKADDR_IN addrSrv;
	void tryConnect(string ipAddress){
		int err;
		wVersionRequested=MAKEWORD(1,1);
		err=WSAStartup(wVersionRequested,&wsaData);
		if (err!=0){
			puts("[ERR] ���� Winsock ��ʧ�ܣ�");
			return;
		}
		if (LOBYTE(wsaData.wVersion)!=1 || HIBYTE(wsaData.wVersion)!=1){
			puts("[ERR] ���� Winsock ��汾����");
			WSACleanup();
			return;
		}
		sockClient=socket(AF_INET,SOCK_STREAM,0);
		addrSrv.sin_addr.S_un.S_addr=inet_addr(ipAddress.c_str());
		addrSrv.sin_family=AF_INET;
		addrSrv.sin_port=htons(6000);
		connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR));
		char recvBuf[100];
		recv(sockClient,recvBuf,100,0);
	}
	void disConnect(){
		closesocket(sockClient);
		WSACleanup();
	}
	string tryReceive(){
		char recvBuf[100];
		recv(sockClient,recvBuf,100,0);
		int len=strlen(recvBuf);
		string res;
		for (int i=0;i<len;++i) res=res+recvBuf[i];
		//cerr<<"��������Ϣ"<<res<<endl;
		return res;
	}
	void trySend(string s){
		//cerr<<"��������Ϣ"<<s<<endl;
		send(sockClient,s.c_str(),strlen(s.c_str())+1,0);
	}
}
namespace Server{
	WORD wVersionRequested;
	WSADATA wsaData;
	SOCKET sockSrv,sockConn;
	SOCKADDR_IN addrSrv,addrClient;
	void init(){
		int err;
		wVersionRequested=MAKEWORD(1,1);
		err=WSAStartup(wVersionRequested,&wsaData);
		if (err!=0){
			puts("[ERR] ���� Winsock ��ʧ�ܣ�");
		}
		if (LOBYTE(wsaData.wVersion)!=1 || HIBYTE(wsaData.wVersion)!=1){
			puts("[ERR] ���� Winsock ��汾����");
			WSACleanup();
		}
		sockSrv=socket(AF_INET,SOCK_STREAM,0);
		addrSrv.sin_addr.S_un.S_addr=htonl(INADDR_ANY);
		addrSrv.sin_family=AF_INET;
		addrSrv.sin_port=htons(6000);
		bind(sockSrv,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR));
		listen(sockSrv,10);
	}
	void tryConnect(){
		int len=sizeof(SOCKADDR); 
		sockConn=accept(sockSrv,(SOCKADDR*)&addrClient,&len);
		send(sockConn,"ready",strlen("ready")+1,0);
	}
	void disConnect(){
		closesocket(sockConn);
	}
	string tryReceive(){
		char recvBuf[100];
		recv(sockConn,recvBuf,100,0);
		int len=strlen(recvBuf);
		string res;
		for (int i=0;i<len;++i) res=res+recvBuf[i];
		//cerr<<"��������Ϣ"<<res<<endl;
		return res;
	}
	void trySend(string s){
		//cerr<<"��������Ϣ"<<s<<endl;
		send(sockConn,s.c_str(),strlen(s.c_str())+1,0);
	}
}
void showCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=1;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void hideCursor(){
    HANDLE fd=GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cinfo;
    cinfo.bVisible=0;
    cinfo.dwSize=1;
    SetConsoleCursorInfo(fd,&cinfo);
}
void setColor(int colorID){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),colorID);
}
void clrscr(){
    setColor(0x0f);system("cls");
}
int charToHex(char c){
    if (c>='0' && c<='9') return c-'0';
    else return c-'a'+10;
}
void gotoxy(int x,int y){
    COORD pos;
    pos.X=y-1;
    pos.Y=x-1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
pair <int,int> getxy(){
    HANDLE hStdout;
    CONSOLE_SCREEN_BUFFER_INFO pBuffer; 
    hStdout=GetStdHandle(STD_OUTPUT_HANDLE); 
    GetConsoleScreenBufferInfo(hStdout,&pBuffer); 
    return make_pair(pBuffer.dwCursorPosition.Y+1,pBuffer.dwCursorPosition.X+1);
}
void tellraw(string s,...){
    va_list ap;va_start(ap,s);
    int len=s.size();setColor(0x0f);
    int foreColor=15,backColor=0,crlf=getxy().second;
    bool change=false;
    for (int i=0;i<len;++i){
        if (s[i]=='%'){
            if (change) setColor(foreColor+backColor*16),change=false;
            if (s[i+1]=='s') cout<<va_arg(ap,char*);
            else if (s[i+1]=='d') cout<<va_arg(ap,int);
            i++;
        }else if (s[i]=='&'){
            foreColor=charToHex(s[i+1]);
            change=true;i++;
        }else if (s[i]=='#'){
            backColor=charToHex(s[i+1]);
            change=true;i++;
        }else if (s[i]=='/'){
            if (change) setColor(foreColor+backColor*16),change=false;
            if (s[i+1]=='/') putchar('/');
            else if (s[i+1]=='#') putchar('#');
            else if (s[i+1]=='%') putchar('%');
            else if (s[i+1]=='&') putchar('&');
            else if (s[i+1]=='n'){
                pair <int,int> tmp=getxy();
                gotoxy(tmp.first,crlf-1);
            }
            else if (s[i+1]=='c') clrscr(); 
            i++;
        }else{
            if (change) setColor(foreColor+backColor*16),change=false;
            putchar(s[i]);
        }
    }
    setColor(0x0f);va_end(ap);
}
int chosenbox(string s){
    int len=s.size(),i=0;
    pair <int,int> tmp=getxy();
    string t="";
    while (s[i]!='@' && i<len) t=t+s[i],i++;
    tellraw(t);
    int j=i;
    t="";
    int item=0;
    for (int i=j+1;i<len;++i){
        if (s[i]=='^'){ 
            j=i;
            break;
        }else if (s[i]=='@'){
            item++;
            gotoxy(tmp.first+item,tmp.second);
            tellraw("    &b%d. &f"+t+"/n",item);
            t="";
        }else{
            t=t+s[i];
        }
    }
    t="";
    for (int i=j+1;i<len;++i){
        t=t+s[i];
    }
    gotoxy(tmp.first+item+1,tmp.second);
    tellraw(t);
    gotoxy(tmp.first+1,tmp.second);
    tellraw("&f-->");
    char c=_getch();
    int chosen=1;
    while (c!=' '){
        if (c=='W' || c=='w'){
            if (chosen>1){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen--;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw("&f-->");
            }
        }else if (c=='S' || c=='s'){
            if (chosen<item){
                gotoxy(tmp.first+chosen,tmp.second);
                chosen++;
                printf("   ");
                gotoxy(tmp.first+chosen,tmp.second);
                tellraw("&f-->");
            }           
        }else if (c>='1' && c<='9' && c-48<=item){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=c-48;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }else if (c=='A' || c=='a'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=1;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }else if (c=='D' || c=='d'){
            gotoxy(tmp.first+chosen,tmp.second);
            chosen=item;
            printf("   ");
            gotoxy(tmp.first+chosen,tmp.second);
            tellraw("&f-->");           
        }
        c=_getch();
    }
    gotoxy(tmp.first+item+2,tmp.second);
    return chosen;
}
